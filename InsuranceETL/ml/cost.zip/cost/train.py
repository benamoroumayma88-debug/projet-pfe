"""
ml/cost/train.py
Train regression model to predict claim cost amounts.  
This model is intended to estimate monthly costs that should be
reserved for incoming claims.  It uses the unified `claim_cost`
column produced by the ETL pipeline and trains both a random forest
and an XGBoost regressor, saving the best performing model.
"""

import pandas as pd
import numpy as np
import os
import sys
import joblib
from datetime import datetime

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score, mean_squared_error, roc_auc_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
import xgboost as xgb

# adjust path to import extract_table from ETL
# ensure the repository root is on sys.path so that both
# InsuranceETL and InsuranceML packages are importable.  Climb
# three directories from this file: cost -> ml -> InsuranceML -> repo root.
project_root = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, project_root)
from etl.extract import extract_table

# database helpers
try:
    from etl.load import load_table
    from etl.db_connection import get_connection
except ImportError:
    from etl.load import load_table
    from etl.db_connection import get_connection

try:
    from etl.extract import extract_table
except ImportError:
    # fallback: maybe script executed as module, try direct etl import
    try:
        from etl.extract import extract_table
    except ImportError:
        raise

# Configuration
MODEL_DIR = "ml/cost/models"
DATA_TABLE = "ml.ml_claim"
TARGET_COL = "claim_cost"    # unified target created in ml_builders
TEST_SIZE = 0.2
RANDOM_STATE = 42
CLOSED_STATUSES = ['Clos_avec_indemnisation', 'Clos_sans_indemnisation', 'Refusé']


def load_data():
    """Load ML dataset from database and filter for rows with cost labels."""
    print("[LOAD] Loading ML dataset from database...")
    df = extract_table(DATA_TABLE)
    print(f"[LOAD] Loaded {len(df)} rows with {len(df.columns)} columns")
    return df


def preprocess_data(df):
    """Prepare features and target for regression.
    Drops rows where the cost target is missing and separates features.

    If the unified target column is absent, try to construct it using the raw
    indemnisation or estimated damage amounts so that the training script can
    still run on older ETL outputs or ad-hoc datasets.
    """
    # filter for closed claims only
    if 'statut_sinistre_claim' in df.columns:
        df = df[df['statut_sinistre_claim'].isin(CLOSED_STATUSES)].copy()
        print(f"[PREPROCESS] Filtered to {len(df)} closed claims")
    else:
        print("[WARNING] status column missing; using all claims for training")

    # ensure target column exists
    if TARGET_COL not in df.columns:
        print(f"[PREPROCESS] warning: {TARGET_COL} not found, attempting fallback")
        if "montant_indemnisation_claim" in df.columns:
            df[TARGET_COL] = df["montant_indemnisation_claim"].copy()
        elif "montant_estime_dommage_claim" in df.columns:
            df[TARGET_COL] = df["montant_estime_dommage_claim"].copy()
        else:
            raise KeyError(f"{TARGET_COL} is missing and no fallback columns are available")

    # cost target must be numeric
    df = df[df[TARGET_COL].notna()].copy()
    df[TARGET_COL] = pd.to_numeric(df[TARGET_COL], errors="coerce")

    if df.empty:
        raise ValueError("No rows with cost target available for training")

    # drop identifiers and leakage columns
    drop_cols = [
        "claim_id", "client_id", "contract_id", "vehicle_id",
        "date_sinistre_claim", "est_frauduleux_claim",
        # severity bucket is derived directly from cost; leaking it would make
        # the prediction trivial.
        "claim_severity_bucket",
        # also drop the raw cost columns since we use the unified target
        "montant_indemnisation_claim", "montant_estime_dommage_claim",
        "montant_indemnisation", "montant_estime"
    ]
    # ensure the target column is not used as a feature (data leakage)
    if TARGET_COL in df.columns:
        drop_cols.append(TARGET_COL)

    X = df.drop(columns=[c for c in drop_cols if c in df.columns], errors="ignore")
    y = df[TARGET_COL]

    # identify numeric/categorical columns
    numeric_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = X.select_dtypes(include=['object', 'category']).columns.tolist()

    print(f"[PREPROCESS] Preparing {len(numeric_cols)} numeric and {len(categorical_cols)} categorical features")
    print(f"[PREPROCESS] Target distribution: count={len(y)}, mean={y.mean():.2f}, std={y.std():.2f}")

    # create preprocessing pipeline
    numeric_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])

    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])

    preprocessor = ColumnTransformer(transformers=[
        ('num', numeric_transformer, numeric_cols),
        ('cat', categorical_transformer, categorical_cols)
    ])

    return X, y, preprocessor


def train_models(X_train, X_test, y_train, y_test, preprocessor):
    """Train and evaluate two regression algorithms."""
    models = {}
    results = {}

    # Random forest regressor
    print("[TRAIN] Training RandomForestRegressor...")
    rf_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('regressor', RandomForestRegressor(
            n_estimators=100,
            max_depth=10,
            random_state=RANDOM_STATE
        ))
    ])
    rf_pipeline.fit(X_train, y_train)
    rf_pred = rf_pipeline.predict(X_test)
    models['random_forest'] = rf_pipeline
    threshold = y_train.median()
    y_test_binary = (y_test > threshold).astype(int)
    auc = roc_auc_score(y_test_binary, rf_pred)
    results['random_forest'] = {
        'mae': mean_absolute_error(y_test, rf_pred),
        'rmse': np.sqrt(mean_squared_error(y_test, rf_pred)),
        'r2': r2_score(y_test, rf_pred),
        'auc': auc
    }

    # XGBoost regressor
    print("[TRAIN] Training XGBRegressor...")
    xgb_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('regressor', xgb.XGBRegressor(
            n_estimators=100,
            max_depth=6,
            learning_rate=0.1,
            random_state=RANDOM_STATE
        ))
    ])
    xgb_pipeline.fit(X_train, y_train)
    xgb_pred = xgb_pipeline.predict(X_test)
    models['xgboost'] = xgb_pipeline
    threshold = y_train.median()
    y_test_binary = (y_test > threshold).astype(int)
    auc = roc_auc_score(y_test_binary, xgb_pred)
    results['xgboost'] = {
        'mae': mean_absolute_error(y_test, xgb_pred),
        'rmse': np.sqrt(mean_squared_error(y_test, xgb_pred)),
        'r2': r2_score(y_test, xgb_pred),
        'auc': auc
    }

    return models, results


def save_models(models, results, dataset_size):
    os.makedirs(MODEL_DIR, exist_ok=True)
    # choose best model by auc score
    best_name = max(results, key=lambda k: results[k]['auc'])
    best_model = models[best_name]
    print(f"[SAVE] Best model: {best_name} (AUC: {results[best_name]['auc']:.4f})")
    joblib.dump(best_model, os.path.join(MODEL_DIR, 'cost_prediction_model.pkl'))
    for name, model in models.items():
        joblib.dump(model, os.path.join(MODEL_DIR, f"{name}_model.pkl"))
    joblib.dump(results, os.path.join(MODEL_DIR, 'model_results.pkl'))
    print(f"[SAVE] Models and results saved to {MODEL_DIR}")

    # persist performance metrics to database
    try:
        perf_rows = []
        for model_name, metrics in results.items():
            perf_rows.append({
                "Model_Name": model_name,
                "Training_Date": datetime.now(),
                "MAE": float(metrics.get("mae", 0.0)),
                "RMSE": float(metrics.get("rmse", 0.0)),
                "R2": float(metrics.get("r2", 0.0)),
                "Dataset_Size": int(dataset_size)
            })
        perf_df = pd.DataFrame(perf_rows)
        conn = get_connection()
        load_table(conn, "ml", "cost_model_performance", perf_df, mode="append", primary_key=None)
        conn.close()
        print(f"[DB] cost_model_performance logged ({len(perf_df)} rows)")
    except Exception as e:
        print(f"[DB] warning: could not log cost model performance: {e}")


def main():
    print(" COST PREDICTION MODEL TRAINING STARTED")
    df = load_data()
    X, y, preprocessor = preprocess_data(df)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE
    )
    print(f"[SPLIT] Train: {len(X_train)}, Test: {len(X_test)}")
    models, results = train_models(X_train, X_test, y_train, y_test, preprocessor)
    for name, res in results.items():
        print(f"\n[{name.upper()}] MAE: {res['mae']:.2f}  RMSE: {res['rmse']:.2f}  R2: {res['r2']:.4f}  AUC: {res['auc']:.4f}")
    save_models(models, results, len(X_train))
    print("COST PREDICTION MODEL TRAINING COMPLETED")


if __name__ == "__main__":
    main()
